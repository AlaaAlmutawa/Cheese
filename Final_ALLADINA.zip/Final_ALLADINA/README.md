## Visual Analytics 2024
# Say Cheese 
### Interactive visualization built for quick and easy access to information related to French Cheese production environmental impact. 

#### Access the visualization [here](https://alaaalmutawa.github.io/Cheese/index.html)

By Alaa Almutawa & Adina Bondoc <br>
Special Thanks to the data sources: [AGRBALYSE®](https://doc.agribalyse.fr/documentation-en/agribalyse-data/data-access) & [Statista](https://www.statista.com/topics/7370/cheese-in-france/#dossier-chapter3) & [CLAL](https://www.clal.it/en/index.php?section=consegne_country&c=FR&p=D7121__THS_T)


